package empresa;

public interface Animal {
	
	public void emitirSom();
	
	public void dormir();

}

﻿using System;

namespace ConsoleApp.Aula3
{
    class Program
    {
        static void Main(string[] args)
        {
            ExemploLambda exemploLambda = new ExemploLambda();

            ExemploLambda2 exemploLambda2 = new ExemploLambda2();

            ExemploLambda3 exemploLambda3 = new ExemploLambda3();

            ExemploFuncoesLinq exemploFuncoesLinq = new ExemploFuncoesLinq();

            ExemplosExecucaoTardia exemplosExecucaoTardia = new ExemplosExecucaoTardia();

            ExemploQuerysLinq exemploQuerysLinq = new ExemploQuerysLinq();
        }
    }
}
